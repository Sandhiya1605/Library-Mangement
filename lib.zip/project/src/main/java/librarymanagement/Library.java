package librarymanagement;
import java.util.ArrayList;
import java.util.List;

public class Library {
	    private List<Book> books;

	    public Library() {
	        books = new ArrayList<>();
	    }

	    public void addBook(Book book) {
	        books.add(book);
	    }

	    public void removeBook(Book book) {
	        books.remove(book);
	    }

	    public Book searchBook(String title) {
	        for (Book book : books) {
	            if (book.getTitle().equalsIgnoreCase(title)) {
	                return book;
	            }
	        }
	        return null;
	    }
	    public void listAllBooks() {
	        if (books.isEmpty()) {
	            System.out.println("The library is currently empty.");
	        } else {
	            System.out.println("List of all books in the library:");
	            for (Book book : books) {
	                System.out.println(book.getTitle() + " by " + book.getAuthor());
	            }
	        }
	}
}



