package librarymanagement;

public class Admin {

	public static void main(String[] args) {
		Book book1=new Book("Innar Narpadhu","Kabilar",12345,"poem",true);
		Book book2=new Book("Thirukkural","Thiruvalluvar",67890,"poem",true);
		Book book3=new Book("Aathichudi","Avvaiyaar",54321,"poem",true);
		
		User user1=new User("Sandhiya","8925080314");

	        // Borrow and return books
	        user1.borrowBook(book1);
	        user1.borrowBook(book2);
	        user1.listBorrowedBooks();

	        user1.returnBook(book1);
	        user1.listBorrowedBooks();
	        Library books= new Library();
	        books.addBook(book1);
	        books.addBook(book2);
	        books.addBook(book3);
	        System.out.println(books.searchBook("thirual"));
	        books.listAllBooks();
	    }
	}


