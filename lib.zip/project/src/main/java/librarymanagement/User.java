package librarymanagement;

import java.util.ArrayList;
import java.util.List;

public class User {
	String name;
	String contact;
	List<Book> borrowedBooks;
	
	public User(String name, String contact) {
		this.name=name;
		this.contact=contact;
		this.borrowedBooks=new ArrayList<>();
		
	}
	public String getName() {
		return name;
	}
	public String getContact()
	{
		return contact;
	}
	
	public void borrowBook(Book book) {
		if(book.getAvailable()) {
			borrowedBooks.add(book);
			book.setAvailable(false);
			System.out.println(name+"has borrowed the Book:"+book.getTitle());
		}else {
			System.out.println("Sorry the book:"+book.getTitle()+"is not available.");
		}
	}
	
	 public void returnBook(Book book) {
	        if (borrowedBooks.contains(book)) {
	            borrowedBooks.remove(book);
	            book.setAvailable(true);
	            System.out.println(name + " has returned the book: " + book.getTitle());
	        } else {
	            System.out.println(name + " did not borrow the book '" + book.getTitle() + "'.");
	        }
	    }
	 public void listBorrowedBooks() {
	        if (borrowedBooks.isEmpty()) {
	            System.out.println(name + " has not borrowed any books.");
	        } else {
	            System.out.println(name + " has borrowed the following books:");
	            for (Book book : borrowedBooks) {
	                System.out.println(book.getTitle());
	            }
	        }
	    }
}
