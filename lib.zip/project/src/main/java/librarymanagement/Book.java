package librarymanagement;

public class Book {
	private String title;
	private String author;
	private int isbn;
	private String genre;
	private boolean available;
	
	public Book(String title, String author, int isbn, String genre, boolean available) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.available = available;
    }
	
	public String getTitle() {
		return title;
		}
	public void setTitle(String t) {title=t;}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String a) {author=a;}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int i) {
		isbn=i;
	}
	public String getGenre() {
		return genre;
		}
	public void setGenre(String g) {genre=g;}
	public boolean getAvailable() {
		return available;
	}
    public void setAvailable(boolean a) {
    	available=a;
    }
}
